import json
import logging
import os
import azure.functions as func

from azure_sentinel import MicrosoftSentinel
from azure.identity import AzureAuthorityHosts, DefaultAzureCredential
from azure.monitor.ingestion import LogsIngestionClient
import time
import datetime

azure_data_collection_endpoint = "https://tendsmaylogsendpointakzxcj3mxkhtc6-x5lq.eastus-1.ingest.monitor.azure.com"
log_type = "Tenable_WAS_VulnMay"
dcr_rule_id = "dcr-812e4acd740b4eb1ae93da2ab9cd129b"
os.environ["AZURE_CLIENT_ID"] = "9b085d6b-0ac0-4112-bd4e-7723896e5b4e"
os.environ["AZURE_CLIENT_SECRET"] = "oIT8Q~O44WWv_~6UbH-RumkiQbdoo3dLGYxJhcB~"
os.environ["AZURE_TENANT_ID"] = "3adb963c-8e61-48e8-a06d-6dbb0dacea39"

def send_chunk_details_to_sentinel(data):
    try:
        creds = DefaultAzureCredential()
        azure_client = LogsIngestionClient(azure_data_collection_endpoint, credential=creds, logging_enable=True)
        ms_sentinel_obj = MicrosoftSentinel(azure_client)
        # Send to Azure Sentinel here
        print("sending data")
        ms_sentinel_obj.post_data(data, log_type, dcr_rule_id)
    except Exception as e:
        print("error occured")

def main(mytimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()
    
    with open("data.json") as f:
        data = json.load(f)
        send_chunk_details_to_sentinel(data)

    if mytimer.past_due:
        logging.info('The timer is past due!')

    logging.info('Python timer trigger function ran at %s', utc_timestamp)
