import logging

from ..tenable_helper import TenableIO
logs_starts_with = "TenableVM"
function_name = "TenableStartAssetExportJob"

def main(timestamp: int) -> object:
    logging.info(f"{logs_starts_with} {function_name}: Using pyTenable client to create new asset export job")
    tio = TenableIO()
    logging.info(
        f"{logs_starts_with} {function_name}: Requesting a new Asset Export Job from Tenable for timestamp={timestamp}")
    # limiting chunk size to contain 100 assets details. For some bigger
    # containers, each chunk is reported to be some hundreds of MBs resulting
    # into azure function crash due to OOM errors.
    job_id = tio.exports.assets(updated_at=timestamp, chunk_size=100, use_iterator=False)

    logging.info(f"{logs_starts_with} {function_name}: Received a response from Asset Export Job request {job_id}")
    return str(job_id)
