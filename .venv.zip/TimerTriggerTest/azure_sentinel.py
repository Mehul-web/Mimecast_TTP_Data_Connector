"""This file contains MicrosoftSentinel class which is used to post data into log analytics workspace."""

from azure.core.exceptions import HttpResponseError, ClientAuthenticationError
from azure.monitor.ingestion import LogsUploadError
import logging


logs_starts_with = "TenableVM"
function_name = "azure_sentinel"


class MicrosoftSentinel:
    """MicrosoftSentinel class is used to post data into log Analytics workspace."""

    def __init__(self, azure_ingestion_client) -> None:
        """Intialize instance variables for MicrosoftSentinel class."""
        self._ingestion_client = azure_ingestion_client
    
    def on_error(error):
        print("Entered in on error")
        print(f"Error: {error.error}")
        print(f"Failed logs: {error.failed_logs}")

    def post_data(self, events, table_name, dcr_rule_id):
        """Post the given events into the specified table in Log Analytics workspace.

        Args:
            events (list): A list of events to be posted into log analytics workspace.
            table_name (str): The name of the table in Log Analytics workspace.
            dcr_rule_id (str): The rule id of the data collection rule.
        Raises:
            TeamCymruScoutException: If an error occurs while posting the events into sentinel.
        """
        try:
            if not isinstance(events, list):
                events = list(events)
            dcr_stream = "Custom-{}".format(table_name)
            print("before uploading data")
            self._ingestion_client.upload(rule_id=dcr_rule_id, stream_name=dcr_stream, logs=events, on_error=on_error)
            print("after uploading data")
        # except HttpResponseError as error:
        #     logging.error(
        #         f"{logs_starts_with} {function_name}: Http response Error while uploading events to sentinel, Error: {error}.")
        #     raise Exception(
        #         f"Http response Error while uploading events to sentinel, Error: {error}.")
        except LogsUploadError as e:
            print(f"Upload failed: {e}")
            raise Exception()
            # logging.error(
            #     f"{logs_starts_with} {function_name}: Error while uploading events to sentinel, Error: {error}.")
            print("client auth error")
