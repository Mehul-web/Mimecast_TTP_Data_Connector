"""Asset DownloadChunk Orchestrator file"""
import json
import logging
import os

import azure.durable_functions as df

from datetime import timedelta
from ..exports_store import ExportsTableStore, ExportsTableNames, list_tables_in_storage_account
from ..azure_sentinel import AzureSentinel
from ..tenable_helper import TenableIO, TenableStatus, TenableChunkPartitioner
from tenable.errors import APIError

connection_string = os.environ["AzureWebJobsStorage"]
assets_table_name = ExportsTableNames.TenableAssetExportTable.value
checkpoint_table_name = ExportsTableNames.TenableExportCheckpointTable.value
workspace_id = os.environ["WorkspaceID"]
workspace_key = os.environ["WorkspaceKey"]
log_analytics_uri = os.getenv("LogAnalyticsUri", "")
log_type = "Tenable_VM_Assets_144_CL"
assets_table = ExportsTableStore(connection_string, assets_table_name)
download_chunk_schedule_minutes = 1
status_code_exceptions = [400, 401, 403, 404, 429]


def orchestrator_function(context: df.DurableOrchestrationContext):
    """
    Orchestrator function to download chunks from Tenable.io Assets export job.

    Args:
        context: The durable orchestration context

    Returns:
        A list containing the results of three parallel activity calls to download three chunks from TenableAssetsExportJob
    """

    while True:
        logging.info("Starting execution for TenableAssetDownloadChunkOrchestrator for tesing infinite while loop")
        logging.info(
            f"instance id: f{context.instance_id} at {context.current_utc_datetime}")
        next_check = context.current_utc_datetime + timedelta(minutes=download_chunk_schedule_minutes)
        yield context.create_timer(next_check)

main = df.Orchestrator.create(orchestrator_function)
