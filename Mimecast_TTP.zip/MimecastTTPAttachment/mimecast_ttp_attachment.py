"""Get Mimecast TTP Attachment Data and Ingest into Sentinel."""

from SharedCode.utils import Utils
from SharedCode.logger import applogger
from SharedCode import consts
from SharedCode.mimecast_exception import MimecastException, MimecastTimeoutException
from SharedCode.state_manager import StateManager
from SharedCode.sentinel import post_data
import inspect
import json
from datetime import datetime, timedelta
import time


file_share_name = consts.FILE_SHARE_NAME
file_path = "mimecastttpattachment"


class MimecastTTPAttachment(Utils):
    """Mimecast TTP Attachment Class."""

    def __init__(self, start, azure_function_name):
        """Initialize the MimecastTTPImpersonation class.

        Args:
            start(int): The starting time for the timer trigger.
            azure_function_name (str): The name of the Azure function.
        """
        self.checkpoint_obj = StateManager(
            consts.CONN_STRING, file_path, file_share_name
        )
        super().__init__(azure_function_name)
        self.start = start

    def get_ttp_attachment(self):
        """Get the TTP Attachment Data from Mimecast."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            while True:
                if int(time.time()) >= self.start + consts.FUNCTION_APP_TIMEOUT_SECONDS:
                    raise MimecastTimeoutException()
                from_date, to_date, next_page, checkpoint_data = (
                    self.get_from_date_to_date_next_token_checkpoint_data(self.checkpoint_obj)
                )
                if not checkpoint_data:
                    applogger.info(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            self.azure_function_name,
                            "Checkpoint file is empty",
                        )
                    )
                    checkpoint_data = {}
                difference = datetime.strptime(
                                to_date, consts.DATE_TIME_FORMAT
                                ) - datetime.strptime(from_date, consts.DATE_TIME_FORMAT)
                if difference < timedelta(minutes=15):
                    applogger.info(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            self.azure_function_name,
                            "Time difference is less than 15 minutes, stopping the execution"
                        )
                    )
                    break
                checkpoint_data.update({"from_date": from_date, "to_date": to_date})
                payload = {
                    "meta": {
                        "pagination": {
                            "pageSize": consts.MAX_PAGE_SIZE,
                            "pageToken": next_page,
                        }
                    },
                    "data": [{"oldestFirst": True, "from": from_date, "to": to_date}],
                }
                self.authenticate_mimecast_api()
                self.get_ttp_attachment_data_and_ingest_into_sentinel(payload, checkpoint_data)
        except MimecastException:
            raise MimecastException()
        except MimecastTimeoutException:
            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Mimecast: 9:30 mins executed hence breaking.",
                )
            )
            return
        except KeyError as key_error:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.KEY_ERROR_MSG.format(key_error),
                )
            )
            raise MimecastException()
        except Exception as error:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.UNEXPECTED_ERROR_MSG.format(error),
                )
            )
            raise MimecastException()

    def get_ttp_attachment_data_and_ingest_into_sentinel(
        self, payload, checkpoint_data
    ):
        """Get TTP Impersonation data from Mimecast and ingest it into Sentinel.

        Args:
            payload (dict): The payload to send in the POST request.
            checkpoint_data (dict): The checkpoint data.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Fetching TTP Attachment data and ingesting it into sentinel",
                )
            )
            page_number = 1
            while True:
                if int(time.time()) >= self.start + consts.FUNCTION_APP_TIMEOUT_SECONDS:
                    raise MimecastTimeoutException()
                response = self.make_rest_call(
                    method="POST",
                    url=consts.BASE_URL + consts.ENDPOINTS["TTP_ATTACHMENT"],
                    json=payload,
                )
                attachmentlogs = response.get("data")[0].get("attachmentLogs")
                response_pagination = response.get("meta").get("pagination")
                payload_pagination = payload.get("meta").get("pagination")
                if attachmentlogs:
                    applogger.info(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            self.azure_function_name,
                            "Data fetched from page number: {}".format(page_number),
                        )
                    )
                    page_number += 1
                    post_data(
                        json.dumps(attachmentlogs), consts.TABLE_NAME["TTP_ATTACHMENT"]
                    )
                else:
                    applogger.info(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            self.azure_function_name,
                            "Got empty response from Mimecast TTP Attachment",
                        )
                    )
                if "next" not in response_pagination:
                    applogger.info(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            self.azure_function_name,
                            f"Successfully fetched all the data from {checkpoint_data.get('from_date')} to {checkpoint_data.get('to_date')}",
                        )
                    )
                    checkpoint_data.update({"next_page": ""})
                    self.post_checkpoint_data(self.checkpoint_obj, checkpoint_data)
                    break
                else:
                    next_page = response_pagination.get("next")
                    payload_pagination.update({"pageToken": next_page})
                    checkpoint_data.update({"next_page": next_page})
                    self.post_checkpoint_data(self.checkpoint_obj, checkpoint_data)
        except json.decoder.JSONDecodeError as json_error:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.JSON_DECODE_ERROR_MSG.format(json_error),
                )
            )
            raise MimecastException()
        except MimecastException:
            raise MimecastException()
        except MimecastTimeoutException:
            raise MimecastTimeoutException()
        except KeyError as key_error:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.KEY_ERROR_MSG.format(key_error),
                )
            )
            raise MimecastException()
        except Exception as error:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.UNEXPECTED_ERROR_MSG.format(error),
                )
            )
            raise MimecastException()
